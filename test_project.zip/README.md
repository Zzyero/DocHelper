# Test Project

This is a test project for DocHelper.

## Files
- test.js: A simple JavaScript file
